from RobotArm import RobotArm

robotArm = RobotArm('exercise 5')

# Jouw python instructies zet je vanaf hier:
for x in range(8)

# Na jouw code wachten tot het sluiten van de window:
robotArm.wait()